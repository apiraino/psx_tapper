============================================
  PSXSERIAL Version 1.2 (c) 2013 PSXDEV.net
--------------------------------------------
 Special Thanks: Jihad of HITMEN and Shendo
             http://psxdev.net/
============================================

=============
Instructions:
=============
Burn 'PSXSERIAL.ISO' to a CD-ROM and boot it
on your PlayStation 1 (swap trick or modchip).

Once loaded, you should see coloured bars with
the title and version number, website and a
date code. The PlayStation is now ready for
communication with your PC.

Next, place your desired PS-EXE to be uploaded
in the same directory as 'PSXSERIAL.EXE'

Now run 'PSXSERIAL.EXE' on your PC using a
command prompt window. It would be a good idea
to copy and paste a command console to this
folder for easier use.

Now type "PSXSERIAL MAIN.EXE COM1" to upload
'MAIN.EXE' to 'COM1' to your PlayStation 1.
This example string will only work if your
PS-EXE is called 'MAIN.EXE' and your PlayStation
is connected to Communications Port 1 (COM1).

=====
Notes
=====
The date code swaps the order accordingly with
your PlayStation 1 region, so it is different
for others.

EG: Japan = 20130717
EG: Europe = 07172013

Future versions will check the PlayStation BIOS
for the region for more accuracy.


====
Help
====
If you need any help, or wish to report a
glitch, bug, problem or want to send advice
to improve PSXSERIAL, please contact us at
[contact@psxdev.net].
